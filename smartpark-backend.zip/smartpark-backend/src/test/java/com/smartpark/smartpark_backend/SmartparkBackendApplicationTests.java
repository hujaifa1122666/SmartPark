package com.smartpark.smartpark_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartparkBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
